
import React, { useState, useEffect } from "react";
import api from "../../utils/api";

const StudentList = () => {
  const [students, setStudents] = useState([]);
  const [search, setSearch] = useState("");

  useEffect(() => {
    const fetchStudents = async () => {
      try {
        const response = await api.get("/teacher/students");
        setStudents(response.data);
      } catch (err) {
        alert("Failed to fetch students.");
      }
    };
    fetchStudents();
  }, []);

  const filteredStudents = students.filter(student =>
    student.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <input
        type="text"
        placeholder="Search by name"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="block w-full p-2 mb-2 border rounded"
      />
      <ul>
        {filteredStudents.map((student) => (
          <li key={student._id} className="p-2 border-b">
            {student.name} - {student.email}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default StudentList;
