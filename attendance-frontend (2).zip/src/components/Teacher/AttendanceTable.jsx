
import React, { useState, useEffect } from "react";
import api from "../../utils/api";

const AttendanceTable = () => {
  const [attendance, setAttendance] = useState([]);

  useEffect(() => {
    const fetchAttendance = async () => {
      try {
        const response = await api.get("/teacher/attendance");
        setAttendance(response.data);
      } catch (err) {
        alert("Failed to fetch attendance.");
      }
    };
    fetchAttendance();
  }, []);

  return (
    <table className="w-full border-collapse">
      <thead>
        <tr>
          <th className="border px-4 py-2">Student</th>
          <th className="border px-4 py-2">Date</th>
          <th className="border px-4 py-2">Time</th>
        </tr>
      </thead>
      <tbody>
        {attendance.map((record) => (
          <tr key={record._id}>
            <td className="border px-4 py-2">{record.userId.name}</td>
            <td className="border px-4 py-2">{new Date(record.timestamp).toLocaleDateString()}</td>
            <td className="border px-4 py-2">{new Date(record.timestamp).toLocaleTimeString()}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default AttendanceTable;
